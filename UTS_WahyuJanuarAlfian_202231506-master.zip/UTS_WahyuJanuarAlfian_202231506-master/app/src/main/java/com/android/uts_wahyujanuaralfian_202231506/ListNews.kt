package com.android.uts_wahyujanuaralfian_202231506

import android.provider.ContactsContract.Contacts.Photo

data class ListNews(
    val title: String,
    val desc: String,
    val photo: Int
)
